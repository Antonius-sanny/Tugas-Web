<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

include '../koneksi.php';

$data_tamu = mysqli_query($koneksi, "SELECT * FROM tamu ORDER BY tanggal DESC, jam DESC");

$statistik = mysqli_query($koneksi, "
    SELECT tanggal, COUNT(*) as jumlah 
    FROM tamu 
    GROUP BY tanggal 
    ORDER BY tanggal ASC
");

$tanggal = [];
$jumlah = [];
while ($row = mysqli_fetch_assoc($statistik)) {
    $tanggal[] = $row['tanggal'];
    $jumlah[] = $row['jumlah'];
}
?>

<?php
if (isset($_POST['export_excel'])) {
    include '../koneksi.php';

    header("Content-type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Data_Tamu.xls");
    header("Pragma: no-cache");
    header("Expires: 0");

    echo "<table border='1'>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Instansi</th>
            <th>Tujuan</th>
            <th>Tanggal</th>
            <th>Jam</th>
        </tr>";

    $no = 1;
    $query = mysqli_query($koneksi, "SELECT * FROM tamu ORDER BY tanggal DESC, jam DESC");
    while ($row = mysqli_fetch_assoc($query)) {
        echo "<tr>
                <td>$no</td>
                <td>{$row['nama']}</td>
                <td>{$row['instansi']}</td>
                <td>{$row['tujuan']}</td>
                <td>{$row['tanggal']}</td>
                <td>{$row['jam']}</td>
              </tr>";
        $no++;
    }

    echo "</table>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f6f8;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 960px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        h2, h3 {
            color: #333;
        }

        a {
            color: #007BFF;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        form {
            margin: 20px 0;
        }

        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 15px;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        table th {
            background-color: #007BFF;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        canvas {
            max-width: 100%;
            height: auto;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }

        .logout {
            float: right;
        }

        @media (max-width: 600px) {
            .container {
                margin: 20px;
                padding: 20px;
            }

            button {
                width: 100%;
                margin-top: 10px;
            }

            .logout {
                float: none;
                display: block;
                text-align: center;
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Dashboard Admin</h2>
        <p>Selamat datang, <strong><?php echo $_SESSION['username']; ?></strong>
           <span class="logout">| <a href="logout.php">Logout</a></span></p>

        <form method="POST">
            <button type="submit" name="export_excel">Export ke Excel</button>
        </form>

        <h3>Grafik Pengunjung per Hari</h3>
        <canvas id="grafikTamu" width="600" height="300"></canvas>

        <h3>Data Tamu</h3>
        <table>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Instansi</th>
                <th>Tujuan</th>
                <th>Tanggal</th>
                <th>Jam</th>
            </tr>
            <?php
            $no = 1;
            while ($row = mysqli_fetch_assoc($data_tamu)) {
                echo "<tr>
                        <td>{$no}</td>
                        <td>{$row['nama']}</td>
                        <td>{$row['instansi']}</td>
                        <td>{$row['tujuan']}</td>
                        <td>{$row['tanggal']}</td>
                        <td>{$row['jam']}</td>
                      </tr>";
                $no++;
            }
            ?>
        </table>
    </div>

    <script>
        const ctx = document.getElementById('grafikTamu').getContext('2d');
        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($tanggal); ?>,
                datasets: [{
                    label: 'Jumlah Pengunjung',
                    data: <?php echo json_encode($jumlah); ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.7)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
